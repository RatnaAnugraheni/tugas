<?php
// Tentukan folder file yang boleh di download
$folder = "files/";
// Lalu cek menggunakan fungsi file_exist
if (!file_exists($folder.$_GET['file'])) {
  echo "<h1>Access forbidden!</h1>
      <p> Anda tidak diperbolehkan mendownload file ini.</p>";
  exit;
}

// Apabila mendownload file di folder files
else {
  header("Content-Type: octet/stream");
  header("Content-Disposition: attachment; 
  filename=\"".$_GET['file']."\"");
  $fp = fopen($folder.$_GET['file'], "r");
  $data = fread($fp, filesize($folder.$_GET['file']));
  fclose($fp);
  print $data;
}
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>tabel dokumen</title>
</head>

<body>
<table align="center" width="800" border="5" cellspacing="0">
	<tr>
		<td><div align="center">
		<h1>Tabel Dokumen</h1>
	</tr>
	<tr>
		<td><table border="2" align="center" cellspacing="0" cellpadding="0">
			<tr>
			<td>Nama.File</td>
			<td>Token</td>
			<td>TokenStem</td>
</table></td>
	</tr>
</body>
</html>